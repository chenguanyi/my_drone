
"use strict";

let yolo = require('./yolo.js');
let number = require('./number.js');

module.exports = {
  yolo: yolo,
  number: number,
};
