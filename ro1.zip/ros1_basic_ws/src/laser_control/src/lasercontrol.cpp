#include <ros/ros.h>
#include <std_msgs/Bool.h>
#include <std_msgs/UInt8.h>
#include <geometry_msgs/Point.h>
#include <wiringPi.h>
#include <set>  // 添加set头文件用于跟踪已发布的数据

#define LASER_PIN 10

bool laser_state = false;
geometry_msgs::Point current_qr_position;
uint8_t previous_qr_data = 0;

// 添加QR码数据发布者
ros::Publisher qr_data_pub;

void laserCallback(const std_msgs::Bool::ConstPtr& msg)
{
    if(msg->data) {
        digitalWrite(LASER_PIN, LOW);
        delay(500); // 0.5 seconds
        digitalWrite(LASER_PIN, HIGH);
    }
}

// 添加周期性切换IO口电平的函数
void periodicToggle(const ros::TimerEvent&)
{
    laser_state = !laser_state;
    if(laser_state) {
        digitalWrite(LASER_PIN, HIGH);
    } else {
        digitalWrite(LASER_PIN, LOW);
    }
}

// QR码数据回调函数
void qrDataCallback(const std_msgs::UInt8::ConstPtr& msg)
{
    uint8_t current_qr_data = msg->data;

     // 检查该qr_data是否已经发布过
   
        if(current_qr_position.x > 160 && current_qr_position.x < 480) {
            if(current_qr_data != previous_qr_data)
            {
            // 拉低引脚0.5秒
            digitalWrite(LASER_PIN, LOW);
            delay(500);
            digitalWrite(LASER_PIN, HIGH);
            qr_data_pub.publish(*msg);
            ROS_INFO("Published QR data: %d", current_qr_data);
            previous_qr_data = current_qr_data;
            }
        }
    

}

// QR码位置回调函数
void qrPositionCallback(const geometry_msgs::Point::ConstPtr& msg)
{
    current_qr_position = *msg;
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "laser_control_node");
    ros::NodeHandle nh;
    
    // 初始化wiringPi
    if(wiringPiSetup() == -1) {
        ROS_ERROR("Failed to setup wiringPi");
        return 1;
    }
    
    // 设置引脚模式为输出，默认高电平
    pinMode(LASER_PIN, OUTPUT);
    digitalWrite(LASER_PIN, HIGH);
    
    // 创建QR码数据发布者
    qr_data_pub = nh.advertise<std_msgs::UInt8>("/processed_qr_data", 10);
    
    //这个是在route文件来的
    ros::Subscriber sub = nh.subscribe("/laser_control", 1, laserCallback);
    
    // 订阅QR码数据和位置话题 这个直接订阅decorder节点
    ros::Subscriber qr_data_sub = nh.subscribe("/qr_code_data", 1, qrDataCallback);
    ros::Subscriber qr_position_sub = nh.subscribe("/qr_code_position", 1, qrPositionCallback);
    
    // 创建2秒周期的定时器
    // ros::Timer timer = nh.createTimer(ros::Duration(2.0), periodicToggle);
    
    ros::spin();
    
    return 0;
}